import turtle

class Triangle:

    def __init__(self,posX,posY):
        self.posX = posX
        self.posY = posY

    def __str__():
        pass

    def draw(self):
        turtle.begin_fill()
        #turtle.right(60)
        turtle.color("yellow")
        turtle.circle(40, steps = 3)
        turtle.end_fill()
        #turtle.left(60)

#t = Triangle(20,10)
#t.draw()
